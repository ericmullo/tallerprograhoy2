#include <stdio.h>

void sumarEscalar(float* numeros, int tamano, float escalar) {
    // Sumar el escalar a cada número y guardar los resultados en la posición del escalar
    for (int i = 0; i < tamano; i++) {
        numeros[i] += escalar;
        numeros[tamano] += numeros[i];
    }
}

int main() {
    float numeros[5];
    float escalar;

    // Pedir al usuario ingresar los números reales
    printf("Ingrese 5 números reales:\n");
    for (int i = 0; i < 5; i++) {
        printf("Número %d: ", i + 1);
        scanf("%f", &numeros[i]);
    }

    // Pedir al usuario ingresar el número escalar
    printf("Ingrese el número escalar: ");
    scanf("%f", &escalar);

    // Llamar a la función para sumar el escalar a los números y guardar los resultados
    sumarEscalar(numeros, 5, escalar);

    // Imprimir los resultados
    printf("\nResultados:\n");
    for (int i = 0; i < 5; i++) {
        printf("Número %d: %.2f\n", i + 1, numeros[i]);
    }
    printf("Suma total: %.2f\n", numeros[5]);

    return 0;
}

